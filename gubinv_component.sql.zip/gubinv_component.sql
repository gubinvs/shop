-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Окт 05 2025 г., 14:06
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `gubinv_component`
--

-- --------------------------------------------------------

--
-- Структура таблицы `goods_table`
--
-- Создание: Мар 17 2025 г., 08:14
-- Последнее обновление: Окт 01 2025 г., 10:19
--

DROP TABLE IF EXISTS `goods_table`;
CREATE TABLE `goods_table` (
  `id` int(11) NOT NULL,
  `imgLinkPage` text NOT NULL,
  `vendorCode` text NOT NULL,
  `nameComponent` text NOT NULL,
  `manufacturer` text NOT NULL,
  `quantity` int(8) NOT NULL,
  `deliveryТime` int(2) NOT NULL,
  `price` int(8) NOT NULL,
  `bestseller` int(1) NOT NULL,
  `chapter` text NOT NULL,
  `linkPage` text NOT NULL,
  `guid` text NOT NULL,
  `basketImgPath` text NOT NULL,
  `imgLinkIconCard` text NOT NULL,
  `productDescription` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `goods_table`
--

INSERT INTO `goods_table` (`id`, `imgLinkPage`, `vendorCode`, `nameComponent`, `manufacturer`, `quantity`, `deliveryТime`, `price`, `bestseller`, `chapter`, `linkPage`, `guid`, `basketImgPath`, `imgLinkIconCard`, `productDescription`) VALUES
(4, 'https://encomponent.ru/img/img-product/A9F79206/A9F79206_big_1920.jpg', 'A9F79206', 'Выключатель автоматический двухполюсный 6А С iC60N 6кА', 'Schneider Electric', 0, 1, 2500, 0, 'Модульные автоматы', 'https://encomponent.ru/comp-page/vendorCode_A9F79206_page.php', '8847d67a-a9ac-42ac-8c12-44138ac47328', 'https://encomponent.ru/img/img-product/A9F79206/A9F79206_basket_icon.jpg', 'https://encomponent.ru/img/img-product/A9F79206/A9F79206_icon-card.jpg', 'Провода'),
(8, 'https://encomponent.ru/img/img-product/PUGVNG-115B%D0%A1-200/PUGVNG-115B%D0%A1-200_img_page.jpg', 'PUGVNG-115BС-200', 'Провод ПуВнг(A)-LS 1x1,5 мм² Черный в коробке по 200 метров', 'Цветлит', 0, 1, 2800, 0, 'Клеммы и провода', 'https://encomponent.ru/comp-page/vendorCode_PUGVNG115B%D0%A1-200_page.php', 'f78eebea-788c-4880-9c62-94313ffb2bd1', 'https://encomponent.ru/img/img-product/PUGVNG-115B%D0%A1-200/PUGVNG-115B%D0%A1-200_img_card.jpg', 'https://encomponent.ru/img/img-product/PUGVNG-115B%D0%A1-200/PUGVNG-115B%D0%A1-200_img_card.jpg', 'Провода'),
(9, 'https://encomponent.ru/img/img-product/PUGVNG-115RC-200/PUGVNG-115RC-200_img_page.jpg', 'PUGVNG-115RC-200', 'Провод ПуВнг(A)-LS 1x1,5 мм² Красный в коробке по 200 метров', 'Цветлит', 0, 1, 2800, 0, 'Клеммы и провода', 'https://encomponent.ru/comp-page/vendorCode_PUGVNG-115RC-200_page.php', '1ff01f94-a296-43a3-8e25-ee4a5147acfa', 'https://encomponent.ru/img/img-product/PUGVNG-115RC-200/PUGVNG-115RC-200_img_page.png', 'https://encomponent.ru/img/img-product/PUGVNG-115R%D0%A1-200/PUGVNG-115R%D0%A1-200_img_card.jpg', 'Провода'),
(10, 'https://encomponent.ru/img/img-product/PUGVNG-115BLUEC-200/PUGVNG-115BLUEC-200_img_page.jpg', 'PUGVNG-115BLUEC-200', 'Провод ПуВнг(A)-LS 1x1,5 мм² Синий в коробке по 200 метров', 'Цветлит', 0, 1, 2800, 0, 'Клеммы и провода', 'https://encomponent.ru/comp-page/vendorCode_PUGVNG-115BLUEC-200_page.php', '7719a5d3-25ea-493f-b44a-2e2124e2df1b', 'https://encomponent.ru/img/img-product/PUGVNG-115BLUEC-200/PUGVNG-115BLUEC-200_img_card.jpg', 'https://encomponent.ru/img/img-product/PUGVNG-115BLUEC-200/PUGVNG-115BLUEC-200_img_card.jpg', 'Провода'),
(11, 'https://encomponent.ru/img/img-product/PUGVNG-115YC-200/PUGVNG-115YC-200_img_page.jpg', 'PUGVNG-115YC-200', 'Провод силовой ПуГВ нг(А)-LS 1х1,5 Желто-зеленый в коробке по 200 метров', 'Цветлит', 0, 1, 2800, 0, 'Клеммы и провода', 'https://encomponent.ru/comp-page/vendorCode_PUGVNG-115YC-200_page.php', 'ba771934-b97d-447f-9830-8127407490ab', 'https://encomponent.ru/img/img-product/PUGVNG-115YC-200/PUGVNG-115YC-200_img_card.jpg', 'https://encomponent.ru/img/img-product/PUGVNG-115YC-200/PUGVNG-115YC-200_img_card.jpg', 'Провода'),
(12, 'https://encomponent.ru/img/img-product/PUGVNG-115WC-200/PUGVNG-115WC-200_img_page.jpg', 'PUGVNG-115WC-200', 'Провод силовой ПуГВ нг(А)-LS 1х1,5 Белый в коробке по 200 метров', 'Цветлит', 0, 1, 2800, 0, 'Клеммы и провода', 'https://encomponent.ru/comp-page/vendorCode_PUGVNG-115WC-200_page.php', 'dc5d9da9-74fc-40cb-92d4-76dc390da920', 'https://encomponent.ru/img/img-product/PUGVNG-115WC-200/PUGVNG-115WC-200_img_card.jpg', 'https://encomponent.ru/img/img-product/PUGVNG-115WC-200/PUGVNG-115WC-200_img_card.jpg', 'Провода'),
(17, 'https://shop.encomponent.ru/img/img-product/2903148/2903148_big_1920.jpg', '2903148', 'Источник питания TRIO-PS-2G/1AC/24DC/5 DIN', 'PHOENIX CONTACT', 0, 1, 17500, 0, 'Блоки питания', 'https://encomponent.ru/comp-page/vendorCode_2903148_page.php', '8b1afa65-1278-40d6-8d42-c40210d4e28f', 'https://encomponent.ru/img/img-product/2903148/2903148_basket_icon.jpg', 'https://encomponent.ru/img/img-product/2903148/2903148_icon-card.jpg', 'Источник питания TRIO POWER с зажимами Push-in. Номинальное напряжение на выходе - 24 В постоянного тока (DC), диапазон выходного напряжения от 24 В до 28 В. Номинальный выходной ток - 5 A. Номинальная выходная мощность - 120 Вт. Диапазон входных напряжений переменного тока - от 100 В AC до 240 В AC (в пределах от -15 % до +10 %). Потребляемая из сети мощность - 272 ВА. Ток динамической перегрузки (I Dyn Boost) - 7,5 A в течение 5 с. Защитная цепь на основе варистора. Внутренний входной предохранитель с номинальным током 6,3 А. Для защиты устройства можно на вводе использовать автоматический выключатель или предохранитель с номинальным током от 6 A до 16 A с характеристикой B, C, D, K. Степень защиты - IP20. Габаритные размеры: ширина - 35 мм, высота - 130 мм, глубина - 115 мм. Диапазон рабочих температур окружающей среды: минимальная температура окружающей среды при эксплуатации -25°С, максимальная температура окружающей среды при эксплуатации 70°С.'),
(21, 'https://encomponent.ru/img/img-product/A9V41263/A9V41263_big_1920.jpg', 'A9V41263', 'Блок дифференциальной защиты VIGI iC60 2P 63A 30 мA', 'Schneider Electric', 2, 1, 27400, 0, 'Модульные автоматы', 'https://encomponent.ru/comp-page/vendorCode_A9V41263_page.php', 'eeaf3e0e-05cb-4934-9f3c-d576381ff122', 'https://encomponent.ru/img/img-product/A9V41263/A9V41263_basket_icon.jpg', 'https://encomponent.ru/img/img-product/A9V41263/A9V41263_icon-card.jpg', 'БЛОК ДИФФ. ЗАЩ. Vigi iC60 2П 63A 30mA AC-ТИП. Данный блок не является самостоятельным устройством и не может быть использован с автоматическими выключателями других серий. В сочетании с автоматическим выключателем iC60, блок Vigi iC60 выполняет следующие функции: защита людей от поражения электротоком при прямом прикосновении (y 30 мА); защита людей от поражения электротоком при косвенном прикосновении (u 100 мА); защита электроустановок от риска возгорания (300 - 500 мА).'),
(22, 'https://shop.encomponent.ru/img/img-product/2866763/2866763_big_1920.jpg', '2866763', 'Источник питания QUINT-PS/1AC/24DC/10', 'PHOENIX CONTACT', 0, 1, 26000, 0, 'Блоки питания', 'https://encomponent.ru/comp-page/vendorCode_2866763_page.php', '3d580315-7423-468c-a364-b60fece71421', 'https://encomponent.ru/img/img-product/2866763/2866763_basket_icon.jpg', 'https://encomponent.ru/img/img-product/2866763/2866763_icon-card.jpg', 'Блок питания с первичным управлением QUINT POWER, винтовое соединение, монтаж на DIN-рейку, технология SFB (Selective Fuse Breaking), вход: 1-фазный, выход: 24 В пост. тока / 10 А'),
(27, 'https://encomponent.ru/img/img-product/TM241CE40T/TM241CE40T_big_1920.jpg', 'TM241CE40T', 'Контроллер M241-40IO транзисторный источник ETHERNET', 'Schneider Electric', 1, 1, 52000, 1, 'Программируемые контроллеры', 'https://encomponent.ru/comp-page/vendorCode_TM241CE40T_page.php', '9b8360c6-f2e8-4de3-833b-4b61a61b5ea2', 'https://encomponent.ru/img/img-product/TM241CE40T/TM241CE40T_basket_icon.jpg', 'https://encomponent.ru/img/img-product/TM241CE40T/TM241CE40T_icon-card.jpg', 'Компактный Базовый блок M241-40 поможет достичь максимальной производительности с повышением прибыльности. Интуитивно понятное машинное программирование с ПО SoMachine с готовыми к использованию приложениями и функциональными блоками, гибкое и масштабируемое управление машиной повысит уровень производительности для улучшения эффективности. Возможно подключение в любом месте через Ethernet.\r\nПреимущества: Максимизируйте прибыльность и повышайте энергетическую эффективность путем мастабируемого управления автоматикой с помощью Modicon, интуитивно-понятный ПО для станков обеспечивает более эффективный технологический прогресс.'),
(28, 'https://encomponent.ru/img/img-product/TM241CE24T/TM241CE24T_big_1920.jpg', 'TM241CE24T', 'Контроллер M241-24IO транзисторный источник ETHERNET', 'Schneider Electric', 2, 1, 48000, 1, 'Программируемые контроллеры', 'https://encomponent.ru/comp-page/vendorCode_TM241CE24T_page.php', '61b3c0ba-4a87-4e16-a173-960721965f15', 'https://encomponent.ru/img/img-product/TM241CE24T/TM241CE24T_basket_icon.jpg', 'https://encomponent.ru/img/img-product/TM241CE24T/TM241CE24T_icon-card.jpg', 'Компактный Базовый блок M241-24 поможет достичь максимальной производительности с повышением прибыльности. Интуитивно понятное машинное программирование с ПО SoMachine с готовыми к использованию приложениями и функциональными блоками, гибкое и масштабируемое управление машиной повысит уровень производительности для улучшения эффективности. Возможно подключение в любом месте через Ethernet.\r\nПреимущества: Максимизируйте прибыльность и повышайте энергетическую эффективность путем мастабируемого управления автоматикой с помощью Modicon, интуитивно-понятное ПО для станков обеспечивает более эффективный технологический прогресс.'),
(29, 'https://encomponent.ru/img/img-product/TM3DQ16T/TM3DQ16T_big_1920.jpg', 'TM3DQ16T', 'Дискретный модуль расширения ТМ3- 16 выходов транзист источник', 'Schneider Electric', 9, 1, 16600, 1, 'Модули расширения', 'https://encomponent.ru/comp-page/vendorCode_TM3DQ16T_page.php', 'd2e44757-34ee-43bc-a734-0624ff3f5a45', 'https://encomponent.ru/img/img-product/TM3DQ16T/TM3DQ16T_basket_icon.jpg', 'https://encomponent.ru/img/img-product/TM3DQ16T/TM3DQ16T_icon-card.jpg', 'Дискретный модуль расширения ТМ3- 16 выходов транзист источник. Серия продукта - Modicon TM3. Тип устройства или его аксессуаров модуль дискретного вывода - совместимость серий продукта - Modicon M221, Modicon M241, Modicon M251 - тип дискретного выхода транзисторный - логика дискретного выхода положительная логика (источник). Специальная функция Модули расширения Modicon TM3 комплектуются простым механизмом соединения сборочных единиц. Соединитель расширения по шине используется для распределения данных и электропитания при сборке модулей расширения Modicon TM3 с логическими контроллерами.'),
(32, 'https://encomponent.ru/img/img-product/TM3DQ8T/TM3DQ8T_big_1920.jpg', 'TM3DQ8T', 'SE Дискретный модуль расширения ТМ3 8 выходов транзисторный источник', 'Schneider Electric', 2, 1, 16200, 1, 'Модули расширения', 'https://encomponent.ru/comp-page/vendorCode_TM3DQ8T_page.php', 'a625c2ea-f94e-4b73-aa9a-24c4e2c5038a', 'https://encomponent.ru/img/img-product/TM3DQ8T/TM3DQ8T_basket_icon.jpg', 'https://encomponent.ru/img/img-product/TM3DQ8T/TM3DQ8T_icon-card.jpg', 'Дискретный модуль расширения является частью серии Modicon TM3, расширения ввода/вывода для Modicon M221, M241, M251 и M262. Модуль дискретного вывода обеспечивает 8 транзисторных выходов с логикой источника (положительной). Модуль вывода с выходным напряжением 24 В постоянного тока и потреблением тока 20 мА при 24 В постоянного тока через разъем шины. Модуль способен управлять приводами с переменной скоростью или любым устройством, оснащенным входом тока или напряжения. Между выходом и внутренней логикой имеется изоляция при 500 В переменного тока, между выходами нет изоляции. Он оснащен съемной винтовой клеммой для электрического соединения с регулировкой шага 5,08 мм для выходов. Степень защиты IP20. Размеры составляют 27,4 мм (ширина) x 84,6 мм (глубина) x 90 мм (высота). Он весит 0,110 кг. Этот модуль совместим с логическими контроллерами Modicon M262, Modicon M241, Modicon M251 и Modicon M221. Он поддерживает рейку top hat TH35-15, top hat TH35-7.5, соответствующую IEC 60715, а также пластину или панель с креплением с помощью комплекта для крепления. Модули расширения Modicon TM3 разработаны с простым механизмом сборки с блокировкой. Разъем расширения шины используется для распределения данных и питания при сборке модулей Modicon TM3 с логическими контроллерами. Повысьте производительность вашего контроллера с помощью системы ввода-вывода Modicon TM3, специально разработанной для логических контроллеров Modicon M221, M241 и M251.'),
(33, 'https://encomponent.ru/img/img-product/TM3DI16/TM3DI16_big_1920.jpg', 'TM3DI16', 'Дискретный модуль расширения ТМ3- 16 входов', 'Schneider Electric', 1, 1, 16200, 1, 'Модули расширения', 'https://encomponent.ru/comp-page/vendorCode_TM3DI16_page.php', 'dfc8f2bd-219c-4a72-80de-c907d1526b4e', 'https://encomponent.ru/img/img-product/TM3DI16/TM3DI16_basket_icon.jpg', 'https://encomponent.ru/img/img-product/TM3DI16/TM3DI16_icon-card.jpg', 'Модули расширения Modicon TM3 комплектуются простым механизмом соединения сборочных единиц. Соединитель расширения по шине используется для распределения данных и электропитания при сборке модулей расширения Modicon TM3 с логическими контроллерами.');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `goods_table`
--
ALTER TABLE `goods_table`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `goods_table`
--
ALTER TABLE `goods_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
